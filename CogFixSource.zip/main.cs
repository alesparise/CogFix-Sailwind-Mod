﻿using System.Reflection;
using BepInEx;
using HarmonyLib;
using UnityEngine;
//poorly written by pr0skynesis (discord username)

namespace CogFix
{
    [BepInPlugin(pluginGuid, pluginName, pluginVersion)]
    public class CogFixMain : BaseUnityPlugin
    {
        // Necessary plugin info
        public const string pluginGuid = "pr0skynesis.cogfix";
        public const string pluginName = "CogFix";
        public const string pluginVersion = "1.0.0";

        //config file info
        
        public void Awake()
        {
            //patching info
            Harmony harmony = new Harmony(pluginGuid);
            MethodInfo original = AccessTools.Method(typeof(PurchasableBoat), "Awake");
            MethodInfo patch = AccessTools.Method(typeof(CogFixPatches), "AwakePatch");

            harmony.Patch(original, new HarmonyMethod(patch)); //patch applied
            
        }
    }
    
    public class CogFixPatches
    {   // Contains the patches
        // Variables
        private static AssetBundle bundle;
        private static string assetPath;
        private static Mesh cog_hull_fixed;
        // NOTE: To get the properly flush deck on the cog you also need to disable the
        // BOAT medi small (40) → medi small → structure → trim_015 (which are the steps)
        [HarmonyPrefix]
        public static void AwakePatch(PurchasableBoat __instance)
        {
            GameObject boat = __instance.gameObject;
            
            Debug.LogWarning("CogFix: Patch Applied");
            Debug.LogWarning($"CogFix: PurchasableBoat attached to: {boat}");
            if (boat.name.Contains("(40)"))
            {   // this is the cog
                SetupThings();          // load the new mesh from the assetBundle
                // replace the mesh
                if (cog_hull_fixed != null)
                {   //navigate to the mesh of the hull object in the hierarchy (to check the hierarchy you can either use the
                    //unity editor or the runtime editor. There are other ways of navigating the Hierarchy more 
                    //precisely, like Find("objectname"), but I like GetChild().
                    boat.transform.GetChild(11).GetChild(12).GetComponent<MeshFilter>().mesh = cog_hull_fixed;
                }
                else
                {
                    Debug.LogWarning($"CogFix: new mesh is null!!!");
                }
            }
        }
        private static void SetupThings()
        {   //this loads the bundle, there is also a check to make sure this works with the way thunderstore sets up 
            //its folders, that's unnecessary for this test mod, but I copy pasted it from another mod so might as well
            //leave it.
            assetPath = Paths.PluginPath + "\\CogFix\\cog_fix";
            bundle = AssetBundle.LoadFromFile(assetPath);
            if (bundle == null)
            {   // Maybe the user downloaded from thunderstore...
                assetPath = Paths.PluginPath + $"\\Pr0SkyNesis-CogFix-{CogFixMain.pluginVersion}" + "\\cog_fix";
                bundle = AssetBundle.LoadFromFile(assetPath);
                if (bundle == null)
                {
                    Debug.LogError("CogFix: Bundle not loaded! Did you place it in the correct folder?");
                }
            }
            if (bundle != null)
            {   // Load the mesh
                string meshPath = $"Assets/CogFix/cog_hull_fixed.asset";
                cog_hull_fixed = bundle.LoadAsset<Mesh>(meshPath);
                if (cog_hull_fixed != null)
                {
                    Debug.LogWarning("CogFix: cog_hull_fixed mesh loaded correctly!!!");
                }
                else
                {
                    Debug.LogError("CogFix: cog_hull_fixed not loaded correctly!!!");
                }
            }
        }
    }
    
}
